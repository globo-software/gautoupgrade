<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

class Gautoupgrade extends Module
{
    public function __construct()
    {
        $this->name = 'gautoupgrade';
        $this->tab = 'administration';
        $this->author = 'Globo';
        $this->version = '1.1.2';
        $this->need_instance = 1;
        $this->module_key = 'e6f54957e022194920dac5079d497e2d';
        $this->bootstrap = true;
        parent::__construct();

        $this->multishop_context = Shop::CONTEXT_ALL;

        if (!defined('_PS_ADMIN_DIR_')) {
            if (defined('PS_ADMIN_DIR')) {
                define('_PS_ADMIN_DIR_', PS_ADMIN_DIR);
            } else {
                $this->_errors[] = $this->trans('This version of PrestaShop cannot be upgraded: the PS_ADMIN_DIR constant is missing.', array(), 'Modules.Gautoupgrade.Admin');
            }
        }

        $this->displayName = $this->trans('1-Click Upgrade to Prestashop 1.7', array(), 'Modules.Gautoupgrade.Admin');
        $this->description = $this->trans('Provides an automated method to upgrade your shop to the latest version of PrestaShop.', array(), 'Modules.Gautoupgrade.Admin');
        if (version_compare(_PS_VERSION_, '1.6.0.0 ', '>='))
            $this->ps_versions_compliancy = array('min' => '1.6.0.0', 'max' => _PS_VERSION_);
        else    $this->ps_versions_compliancy = array('min' => '1.5.0.0', 'max' => '1.5.99.99');
    }

    public function install()
    {
        if (50600 > PHP_VERSION_ID) {
            $this->_errors[] = $this->trans('This version of 1-click upgrade requires PHP 5.6 to work properly. Please upgrade your server configuration.', array(), 'Modules.Gautoupgrade.Admin');
            return false;
        }
        if ($id_tab = Tab::getIdFromClassName('AdminUpgrade')) {
            $tab = new Tab((int) $id_tab);
            if (!$tab->delete()) {
                $this->_errors[] = $this->trans('Unable to delete outdated "AdminUpgrade" tab (tab ID: %idtab%).', array('%idtab%' => (int) $id_tab), 'Modules.Gautoupgrade.Admin');
            }
        }
        if (!$id_tab = Tab::getIdFromClassName('AdminGSelfUpgrade')) {
            $tab = new Tab();
            $tab->class_name = 'AdminGSelfUpgrade';
            $tab->module = 'gautoupgrade';
            $tab->id_parent = (int) Tab::getIdFromClassName('AdminTools');
            foreach (Language::getLanguages(false) as $lang) {
                $tab->name[(int) $lang['id_lang']] = '1-Click Upgrade';
            }
            if (!$tab->save()) {
                return $this->_abortInstall($this->trans('Unable to create the "AdminGSelfUpgrade" tab', array(), 'Modules.Gautoupgrade.Admin'));
            }
            if (!@copy(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'logo.gif', _PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'img' . DIRECTORY_SEPARATOR . 't' . DIRECTORY_SEPARATOR . 'AdminGSelfUpgrade.gif')) {
                return $this->_abortInstall($this->trans('Unable to copy logo.gif in %s', array(_PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'img' . DIRECTORY_SEPARATOR . 't' . DIRECTORY_SEPARATOR), 'Modules.Gautoupgrade.Admin'));
            }
        } else {
            $tab = new Tab((int) $id_tab);
        }

        // Update the "AdminGSelfUpgrade" tab id in database or exit
        if (Validate::isLoadedObject($tab)) {
            Configuration::updateValue('PS_GAUTOUPDATE_MODULE_IDTAB', (int) $tab->id);
        } else {
            return $this->_abortInstall($this->trans('Unable to load the "AdminGSelfUpgrade" tab', array(), 'Modules.Gautoupgrade.Admin'));
        }

        // Check that the 1-click upgrade working directory is existing or create it
        $gautoupgrade_dir = _PS_ADMIN_DIR_ . DIRECTORY_SEPARATOR . 'gautoupgrade';
        if (!file_exists($gautoupgrade_dir) && !@mkdir($gautoupgrade_dir)) {
            return $this->_abortInstall($this->trans('Unable to create the directory "%s"', array($gautoupgrade_dir), 'Modules.Gautoupgrade.Admin'));
        }

        // Make sure that the 1-click upgrade working directory is writeable
        if (!is_writable($gautoupgrade_dir)) {
            return $this->_abortInstall($this->trans('Unable to write in the directory "%s"', array($gautoupgrade_dir), 'Modules.Gautoupgrade.Admin'));
        }

        // If a previous version of ajax-gupgradetab.php exists, delete it
        if (file_exists($gautoupgrade_dir . DIRECTORY_SEPARATOR . 'ajax-gupgradetab.php')) {
            @unlink($gautoupgrade_dir . DIRECTORY_SEPARATOR . 'ajax-gupgradetab.php');
        }

        // Then, try to copy the newest version from the module's directory
        if (!@copy(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'ajax-gupgradetab.php', $gautoupgrade_dir . DIRECTORY_SEPARATOR . 'ajax-gupgradetab.php')) {
            return $this->_abortInstall($this->trans('Unable to copy ajax-gupgradetab.php in %s', array($gautoupgrade_dir), 'Modules.Gautoupgrade.Admin'));
        }

        // Make sure that the XML config directory exists
        if (!file_exists(_PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'xml') &&
        !@mkdir(_PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'xml', 0775)) {
            return $this->_abortInstall($this->trans('Unable to create the directory "%s"', array(_PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'xml'), 'Modules.Gautoupgrade.Admin'));
        } else {
            @chmod(_PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'xml', 0775);
        }

        // Create a dummy index.php file in the XML config directory to avoid directory listing
        if (!file_exists(_PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'xml' . DIRECTORY_SEPARATOR . 'index.php') &&
        (file_exists(_PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'index.php') &&
        !@copy(_PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'index.php', _PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'xml' . DIRECTORY_SEPARATOR . 'index.php'))) {
            return $this->_abortInstall($this->trans('Unable to create the directory "%s"', array(_PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'xml'), 'Modules.Gautoupgrade.Admin'));
        }
        Configuration::updateValue('PS_GAUTOUP_IGNORE_PHP_UPGRADE', 1);
        Configuration::updateValue('PS_GAUTOUP_IGNORE_REQS', 1);
        return (bool)parent::install() && $this->registerHookAndSetToTop('dashboardZoneOne');
    }

    public function uninstall()
    {
        // Delete the 1-click upgrade Back-office tab
        if ($id_tab = Tab::getIdFromClassName('AdminGSelfUpgrade')) {
            $tab = new Tab((int) $id_tab);
            $tab->delete();
        }

        // Remove the 1-click upgrade working directory
        self::_removeDirectory(_PS_ADMIN_DIR_ . DIRECTORY_SEPARATOR . 'gautoupgrade');

        Configuration::deleteByName('PS_GAUTOUP_IGNORE_REQS');
        Configuration::deleteByName('PS_GAUTOUP_IGNORE_PHP_UPGRADE');

        return parent::uninstall();
    }

    /**
     * Register the current module to a given hook and moves it at the first position.
     *
     * @param string $hookName
     *
     * @return bool
     */
    private function registerHookAndSetToTop($hookName)
    {
        return $this->registerHook($hookName) && $this->updatePosition((int) Hook::getIdByName($hookName), 0);
    }

    public function hookDashboardZoneOne($params)
    {
        $dir = _PS_ROOT_DIR_.'/modules/gautoupgrade';
        // Display panel if PHP is not supported by the community
        require_once $dir . '/vendor/autoload.php';

        $upgradeContainer = new \PrestaShop\Module\GautoUpgrade\UpgradeContainer(_PS_ROOT_DIR_, _PS_ADMIN_DIR_);
        $upgrader = $upgradeContainer->getUpgrader();
        $upgradeSelfCheck = new \PrestaShop\Module\GautoUpgrade\UpgradeSelfCheck(
            $upgrader,
            _PS_ROOT_DIR_,
            _PS_ADMIN_DIR_,
            $dir
        );

        $upgradeNotice = $upgradeSelfCheck->isPhpUpgradeRequired();
        if (false === $upgradeNotice) {
            return '';
        }

        $this->context->controller->addCSS($this->_path . '/views/css/admin/styles.css');
        $this->context->controller->addJS($this->_path . '/views/js/admin/dashboard.js');

        $this->context->smarty->assign([
            'ignore_link' => Context::getContext()->link->getAdminLink('AdminGSelfUpgrade') . '&ignorePhpOutdated=1',
            'learn_more_link' => 'http://build.prestashop.com/news/announcing-end-of-support-for-obsolete-php-versions/',
        ]);

        return $this->context->smarty->fetch($this->local_path . 'views/templates/hook/dashboard_zone_one.tpl');
    }

    public function getContent()
    {
        $id_employee = 0;
        if(isset($this->context->employee) && isset($this->context->employee->id) && $this->context->employee->id)
            $id_employee = $this->context->employee->id;
        Tools::redirectAdmin('index.php?tab=AdminGSelfUpgrade&token=' . md5(pSQL(_COOKIE_KEY_ . 'AdminGSelfUpgrade' . (int) Tab::getIdFromClassName('AdminGSelfUpgrade') . (int) $id_employee)));
    }

    /**
     * Set installation errors and return false.
     *
     * @param string $error Installation abortion reason
     *
     * @return bool Always false
     */
    protected function _abortInstall($error)
    {
        $this->_errors[] = $error;

        return false;
    }

    private static function _removeDirectory($dir)
    {
        if ($handle = @opendir($dir)) {
            while (false !== ($entry = @readdir($handle))) {
                if ($entry != '.' && $entry != '..') {
                    if (is_dir($dir . DIRECTORY_SEPARATOR . $entry) === true) {
                        self::_removeDirectory($dir . DIRECTORY_SEPARATOR . $entry);
                    } else {
                        @unlink($dir . DIRECTORY_SEPARATOR . $entry);
                    }
                }
            }

            @closedir($handle);
            @rmdir($dir);
        }
    }

    /**
     * Adapter for trans calls, existing only on PS 1.7.
     * Making them available for PS 1.6 as well.
     *
     * @param string $id
     * @param array $parameters
     * @param string $domain
     * @param string $locale
     */
    public function trans($id, array $parameters = array(), $domain = null, $locale = null)
    {
        require_once _PS_ROOT_DIR_ . '/modules/gautoupgrade/classes/UpgradeTools/Translator.php';

        $translator = new \PrestaShop\Module\GautoUpgrade\UpgradeTools\Translator(__CLASS__);

        return $translator->trans($id, $parameters, $domain, $locale);
    }
}
