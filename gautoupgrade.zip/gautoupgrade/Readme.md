Thank you for using our module.
You must read document & license.txt before use the module.
Contact us if you discover any bugs or have any questions. 

Email: contact@globosoftware.net
Skype: greenwebcorp
Web: www.globosoftware.net