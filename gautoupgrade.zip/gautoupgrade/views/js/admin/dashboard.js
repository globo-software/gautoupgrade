/**
* This is js file. Don't edit the file if you want to update module in future.
* 
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright 2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

$(document).ready(function(){
  var autoUpgradePanel = $("#gautoupgradePhpWarn");

  $(".list-toolbar-btn", autoUpgradePanel).click(function(event) {

    event.preventDefault();
    autoUpgradePanel.fadeOut();

    $.post(
      $(this).attr("href")
    );
  });
});
