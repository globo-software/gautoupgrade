<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

if (PHP_SAPI !== 'cli') {
    echo 'This script must be called from CLI';
    exit(1);
}

require_once realpath(dirname(__FILE__) . '/../../modules/gautoupgrade') . '/ajax-gupgradetabconfig.php';
$container = gautoupgrade_init_container(dirname(__FILE__));

$container->setLogger(new PrestaShop\Module\GautoUpgrade\Log\StreamedLogger());
$controller = new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\AllUpgradeTasks($container);
$controller->setOptions(getopt('', array('action::', 'channel::', 'data::')));
$controller->init();
exit($controller->run());
