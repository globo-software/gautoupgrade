<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

use PrestaShop\Module\GautoUpgrade\Tools14;
use PrestaShop\Module\GautoUpgrade\UpgradeTools\TaskRepository;

/**
 * This file is the entrypoint for all ajax requests during a upgrade, rollback or configuration.
 * In order to get the admin context, this file is copied to the admin/gautoupgrade folder of your shop when the module configuration is reached.
 *
 * Calling it from the module/gautoupgrade folder will have unwanted consequences on the upgrade and your shop.
 */
require_once realpath(dirname(__FILE__) . '/../../modules/gautoupgrade') . '/ajax-gupgradetabconfig.php';
$container = gautoupgrade_init_container(dirname(__FILE__));

(new \PrestaShop\Module\GautoUpgrade\ErrorHandler($container->getLogger()))->enable();

if (!$container->getCookie()->check($_COOKIE)) {
    // If this is an XSS attempt, then we should only display a simple, secure page
    if (ob_get_level() && ob_get_length() > 0) {
        ob_clean();
    }
    echo '{wrong token}';
    http_response_code(401);
    die(1);
}

$controller = TaskRepository::get(Tools14::getValue('action'), $container);
$controller->init();
$controller->run();
echo $controller->getJsonResponse();
