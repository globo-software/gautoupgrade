<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade;

use PrestaShop\Module\GautoUpgrade\Log\Logger;
use PrestaShop\Module\GautoUpgrade\Parameters\UpgradeConfiguration;

/**
 * Class creating the content to return at an ajax call.
 */
class AjaxResponse
{
    /**
     * Used during upgrade.
     *
     * @var bool Supposed to store a boolean in case of error
     */
    private $error = false;

    /**
     * Used during upgrade.
     *
     * @var bool Inform when the step is completed
     */
    private $stepDone = true;

    /**
     * Used during upgrade. "N/A" as value otherwise.
     *
     * @var string Next step to call (can be the same as the previous one)
     */
    private $next = 'N/A';

    /**
     * @var array Params to send (upgrade conf, details on the work to do ...)
     */
    private $nextParams = array();

    /**
     * Request format of the data to return.
     * Seems to be never modified. Converted as const.
     */
    const RESPONSE_FORMAT = 'json';

    /**
     * @var UpgradeConfiguration
     */
    private $upgradeConfiguration;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @var State
     */
    private $state;


    public $totalitem;
    public $leftitem;

    public function __construct(State $state, Logger $logger)
    {
        $this->state = $state;
        $this->logger = $logger;
    }

    /**
     * @return array of data to ready to be returned to caller
     */
    public function getResponse()
    {
        $return = array(
            'error' => $this->error,
            'stepDone' => $this->stepDone,
            'next' => $this->next,

            'totalitem'=>$this->totalitem,
            'leftitem'=>$this->leftitem,

            'status' => $this->getStatus(),
            'next_desc' => $this->logger->getLastInfo(),
            'nextQuickInfo' => $this->logger->getInfos(),
            'nextErrors' => $this->logger->getErrors(),
            'nextParams' => array_merge(
                $this->nextParams,
                $this->state->export(),
                array(
                    'typeResult' => self::RESPONSE_FORMAT,
                    'config' => $this->upgradeConfiguration->toArray(),
                )
            ),
        );

        return $return;
    }

    /**
     * @return string Json encoded response from $this->getResponse()
     */
    public function getJson()
    {
        return json_encode($this->getResponse());
    }

    // GETTERS

    public function getError()
    {
        return $this->error;
    }

    public function getStepDone()
    {
        return $this->stepDone;
    }

    public function getNext()
    {
        return $this->next;
    }

    public function getStatus()
    {
        return $this->getNext() == 'error' ? 'error' : 'ok';
    }

    public function getNextParams()
    {
        return $this->nextParams;
    }

    public function getUpgradeConfiguration()
    {
        return $this->upgradeConfiguration;
    }

    public function setTotalitem($totalitem)
    {
        $this->totalitem = $totalitem;
        return $this;
    }
    public function setLeftitem($leftitem)
    {
        $this->leftitem = $leftitem;
        return $this;
    }

    // SETTERS

    public function setError($error)
    {
        $this->error = (bool) $error;

        return $this;
    }

    public function setStepDone($stepDone)
    {
        $this->stepDone = $stepDone;

        return $this;
    }

    public function setNext($next)
    {
        $this->next = $next;

        return $this;
    }

    public function setNextParams($nextParams)
    {
        $this->nextParams = $nextParams;

        return $this;
    }

    public function setUpgradeConfiguration(UpgradeConfiguration $upgradeConfiguration)
    {
        $this->upgradeConfiguration = $upgradeConfiguration;

        return $this;
    }
}
