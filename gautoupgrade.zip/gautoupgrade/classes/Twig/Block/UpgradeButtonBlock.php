<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\Twig\Block;

use Configuration;
use PrestaShop\Module\GautoUpgrade\ChannelInfo;
use Twig_Environment;
use PrestaShop\Module\GautoUpgrade\Upgrader;
use PrestaShop\Module\GautoUpgrade\Parameters\UpgradeConfiguration;
use PrestaShop\Module\GautoUpgrade\TaskRunner\AbstractTask;
use PrestaShop\Module\GautoUpgrade\UpgradeSelfCheck;
use PrestaShop\Module\GautoUpgrade\UpgradeTools\Translator;

class UpgradeButtonBlock
{
    /**
     * @var \Twig_Environment
     */
    private $twig;

    /**
     * @var Translator
     */
    private $translator;

    /**
     * @var Upgrader
     */
    private $upgrader;

    /**
     * @var UpgradeConfiguration
     */
    private $config;

    /**
     * @var UpgradeSelfCheck
     */
    private $selfCheck;

    /**
     * @var string
     */
    private $downloadPath;

    /**
     * @var string
     */
    private $token;

    /**
     * @var bool
     */
    private $manualMode;

    /**
     * UpgradeButtonBlock constructor.
     *
     * @param Twig_Environment $twig
     * @param Translator $translator
     * @param UpgradeConfiguration $config
     * @param Upgrader $upgrader
     * @param UpgradeSelfCheck $selfCheck
     */
    public function __construct(
        Twig_Environment $twig,
        Translator $translator,
        UpgradeConfiguration $config,
        Upgrader $upgrader,
        UpgradeSelfCheck $selfCheck,
        $downloadPath,
        $token,
        $manualMode
    ) {
        $this->twig = $twig;
        $this->translator = $translator;
        $this->upgrader = $upgrader;
        $this->config = $config;
        $this->selfCheck = $selfCheck;
        $this->downloadPath = $downloadPath;
        $this->token = $token;
        $this->manualMode = $manualMode;
    }

    /**
     * display the summary current version / target version + "Upgrade Now" button with a "more options" button.
     *
     * @return string HTML
     */
    public function render()
    {
        $translator = $this->translator;

        $versionCompare = version_compare(_PS_VERSION_, $this->upgrader->version_num);
        $channel = $this->config->get('channel');

        if (!in_array($channel, array('archive', 'directory')) && !empty($this->upgrader->version_num)) {
            $latestVersion = $this->upgrader->version_num;
        } else {
            $latestVersion = $translator->trans('N/A', array(), 'Admin.Global');
        }

        $showUpgradeButton = false;
        $showUpgradeLink = false;
        $upgradeLink = '';
        $changelogLink = '';
        $skipActions = array();

        // decide to display "Start Upgrade" or not
        if ($this->selfCheck->isOkForUpgrade() && $versionCompare < 0) {
            $showUpgradeButton = true;
            if (!in_array($channel, array('archive', 'directory'))) {
                if ($channel == 'private') {
                    $this->upgrader->link = $this->config->get('private_release_link');
                }

                $showUpgradeLink = true;
                $upgradeLink = $this->upgrader->link;
                $changelogLink = $this->upgrader->changelog;
            }

            // if skipActions property is used, we will handle that in the display :)
            $skipActions = AbstractTask::$skipAction;
        }

        if (empty($channel)) {
            $channel = Upgrader::DEFAULT_CHANNEL;
        }

        $dir = glob($this->downloadPath . DIRECTORY_SEPARATOR . '*.zip');
        $news_vs = $this->upgrader->getPsNewVersion();
        $selected_branch = trim(Configuration::get('G_INSTALL_BRANCH'));
        if(($selected_branch == '' || !isset($news_vs[$selected_branch])) && $news_vs){
            $selected_branch = '1_7';
            Configuration::updateValue('G_INSTALL_BRANCH', '1_7');
        }
        
        $data = array(
            'psBaseUri' => __PS_BASE_URI__,
            'news_vs'=>$news_vs,
            'selected_branch'=>$selected_branch,
            'versionCompare' => $versionCompare,
            'currentPsVersion' => _PS_VERSION_,
            'latestChannelVersion' => $latestVersion,
            'channel' => $channel,
            'showUpgradeButton' => $showUpgradeButton,
            'upgradeLink' => $upgradeLink,
            'showUpgradeLink' => $showUpgradeLink,
            'changelogLink' => $changelogLink,
            'skipActions' => $skipActions,
            'lastVersionCheck' => Configuration::get('PS_LAST_VERSION_CHECK'),
            'token' => $this->token,
            'channelOptions' => $this->getOptChannels(),
            'channelInfoBlock' => $this->buildChannelInfoBlock($channel),
            'privateChannel' => array(
                'releaseLink' => $this->config->get('private_release_link'),
                'releaseMd5' => $this->config->get('private_release_md5'),
                'allowMajor' => $this->config->get('private_allow_major'),
            ),
            'archiveFiles' => $dir,
            'archiveFileName' => $this->config->get('archive.filename'),
            'archiveVersionNumber' => $this->config->get('archive.version_num'),
            'downloadPath' => $this->downloadPath . DIRECTORY_SEPARATOR,
            'directoryVersionNumber' => $this->config->get('directory.version_num'),
            'manualMode' => $this->manualMode,
        );

        return $this->twig->render('@ModuleGautoUpgrade/block/upgradeButtonBlock.twig', $data);
    }

    /**
     * @return array
     */
    private function getOptChannels()
    {
        $translator = $this->translator;


        $channels = array(
            array('useMajor', 'major', $translator->trans('Major release', array(), 'Modules.Gautoupgrade.Admin')),
            array('useMinor', 'minor', $translator->trans('Minor release (recommended)', array(), 'Modules.Gautoupgrade.Admin')),
            /*
            array('useRC', 'rc', $translator->trans('Release candidates', array(), 'Modules.Gautoupgrade.Admin')),
            array('useBeta', 'beta', $translator->trans('Beta releases', array(), 'Modules.Gautoupgrade.Admin')),
            array('useAlpha', 'alpha', $translator->trans('Alpha releases', array(), 'Modules.Gautoupgrade.Admin')),
            array('usePrivate', 'private', $translator->trans('Private release (require link and MD5 hash)', array(), 'Modules.Gautoupgrade.Admin')),
            array('useArchive', 'archive', $translator->trans('Local archive', array(), 'Modules.Gautoupgrade.Admin')),
            array('useDirectory', 'directory', $translator->trans('Local directory', array(), 'Modules.Gautoupgrade.Admin')),
            */
        );

        return $channels;
    }

    private function getInfoForChannel($channel)
    {
        return new ChannelInfo($this->upgrader, $this->config, $channel);
    }

    /**
     * @param string $channel
     *
     * @return string
     */
    private function buildChannelInfoBlock($channel)
    {
        $channelInfo = $this->getInfoForChannel($channel);

        return (new ChannelInfoBlock($this->config, $channelInfo, $this->twig))
            ->render();
    }
}
