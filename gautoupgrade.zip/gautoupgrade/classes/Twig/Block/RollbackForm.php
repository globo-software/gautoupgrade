<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\Twig\Block;

use PrestaShop\Module\GautoUpgrade\BackupFinder;
use Twig_Environment;

class RollbackForm
{
    /**
     * @var Twig_Environment
     */
    private $twig;

    /**
     * @var BackupFinder
     */
    private $backupFinder;

    public function __construct(Twig_Environment $twig, BackupFinder $backupFinder)
    {
        $this->twig = $twig;
        $this->backupFinder = $backupFinder;
    }

    public function render()
    {
        return $this->twig->render(
            '@ModuleGautoUpgrade/block/rollbackForm.twig',
            array(
                'availableBackups' => $this->backupFinder->getAvailableBackups(),
                'psBaseUri' => __PS_BASE_URI__,
                
            )
        );
    }
}
