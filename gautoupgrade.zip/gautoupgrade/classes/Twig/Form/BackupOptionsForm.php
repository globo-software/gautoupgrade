<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\Twig\Form;

use PrestaShop\Module\GautoUpgrade\UpgradeTools\Translator;

class BackupOptionsForm
{
    /**
     * @var array
     */
    private $fields;

    /**
     * @var Translator
     */
    private $translator;

    /**
     * @var FormRenderer
     */
    private $formRenderer;

    public function __construct(Translator $translator, FormRenderer $formRenderer)
    {
        $this->translator = $translator;
        $this->formRenderer = $formRenderer;

        $translationDomain = 'Modules.Gautoupgrade.Admin';

        $this->fields = array(
            'PS_GAUTOUP_BACKUP' => array(
                'title' => $this->translator->trans(
                    'Back up my files and database',
                    array(),
                    $translationDomain
                ),
                'cast' => 'intval',
                'validation' => 'isBool',
                'defaultValue' => '1',
                'type' => 'bool',
                'desc' => $this->translator->trans(
                    'Automatically back up your database and files in order to restore your shop if needed. This is experimental: you should still perform your own manual backup for safety.',
                    array(),
                    $translationDomain
                ),
            ),
            'PS_GAUTOUP_KEEP_IMAGES' => array(
                'title' => $this->translator->trans(
                    'Back up my images',
                    array(),
                    $translationDomain
                ),
                'cast' => 'intval',
                'validation' => 'isBool',
                'defaultValue' => '1',
                'type' => 'bool',
                'desc' => $this->translator->trans(
                    'To save time, you can decide not to back your images up. In any case, always make sure you did back them up manually.',
                    array(),
                    $translationDomain
                ),
            ),
        );
    }

    public function render()
    {
        return $this->formRenderer->render(
                'backupOptions',
                $this->fields,
                $this->translator->trans(
                    'Backup Options',
                    array(),
                    'Modules.Gautoupgrade.Admin'
                ),
                '',
                'database_gear'
            );
    }
}
