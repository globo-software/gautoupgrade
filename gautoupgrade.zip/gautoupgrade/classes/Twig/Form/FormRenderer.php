<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\Twig\Form;

use PrestaShop\Module\GautoUpgrade\Parameters\UpgradeConfiguration;
use PrestaShop\Module\GautoUpgrade\UpgradeTools\Translator;
use Twig_Environment;

class FormRenderer
{
    private $config;

    private $translator;

    private $twig;

    public function __construct(
        UpgradeConfiguration $configuration,
        Twig_Environment $twig,
        Translator $translator
    ) {
        $this->config = $configuration;
        $this->twig = $twig;
        $this->translator = $translator;
    }

    public function render($name, $fields, $tabname, $size, $icon)
    {
        $required = false;
        $size;$icon;

        $formFields = array();

        foreach ($fields as $key => $field) {
            $html = '';
            $required = !empty($field['required']);
            $disabled = !empty($field['disabled']);

            $val = $this->config->get(
                $key,
                isset($field['defaultValue']) ? $field['defaultValue'] : false
            );

            if (!in_array($field['type'], array('image', 'radio', 'select', 'container', 'bool', 'container_end')) || isset($field['show'])) {
                $data = array(
                    'type'=>'startfield',
                    'field'=>$field,
                    'key'=>'',
                    'val'=>''
                );
                $html .= $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
            }

            // Display the appropriate input type for each field
            switch ($field['type']) {
                case 'disabled':
                    $html .= $field['disabled'];
                    break;

                case 'bool':
                    $html .= $this->renderBool($field, $key, $val);
                    break;

                case 'radio':
                    $html .= $this->renderRadio($field, $key, $val, $disabled);
                    break;

                case 'select':
                    $html .= $this->renderSelect($field, $key, $val);
                    break;

                case 'textarea':
                    $html .= $this->renderTextarea($field, $key, $val, $disabled);
                    break;

                case 'container':
                    $data = array(
                        'type'=>'container',
                        'field'=>'',
                        'key'=>$key,
                        'val'=>''
                    );
                    $html .= $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
                    break;

                case 'container_end':
                    $html .= (isset($field['content']) ? $field['content'] : '');
                    $data = array(
                        'type'=>'enddiv',
                        'field'=>'',
                        'key'=>'',
                        'val'=>''
                    );
                    $html .= $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
                    break;
                case 'text':
                default:
                    $html .= $this->renderTextField($field, $key, $val, $disabled);
            }

            if ($required && !in_array($field['type'], array('image', 'radio'))) {
                $data = array(
                    'type'=>'required',
                    'field'=>'',
                    'key'=>'',
                    'val'=>''
                );
                $html .= $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
            }
            if (isset($field['desc']) && !in_array($field['type'], array('bool', 'select'))) {
                $data = array(
                    'type'=>'startp',
                    'field'=>'',
                    'key'=>'',
                    'val'=>''
                );
                $html .= $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
                if (!empty($field['thumb']) && $field['thumb']['pos'] == 'after') {
                    $html .= $this->renderThumb($field);
                }
                $html .= $field['desc'];
                $data = array(
                    'type'=>'endp',
                    'field'=>'',
                    'key'=>'',
                    'val'=>''
                );
                $html .= $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
            }
            if (!in_array($field['type'], array('image', 'radio', 'select', 'container', 'bool', 'container_end')) || isset($field['show'])) {
                $data = array(
                    'type'=>'endfield',
                    'field'=>'',
                    'key'=>'',
                    'val'=>''
                );
                $html .= $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
            }

            $formFields[] = $html;
        }

        return $this->twig->render(
            '@ModuleGautoUpgrade/form.twig',
            array(
                'name' => $name,
                'tabName' => $tabname,
                'fields' => $formFields,
            )
        );
    }
    private function renderBool($field, $key, $val){
        $data = array(
            'type'=>'bool',
            'field'=>$field,
            'key'=>$key,
            'val'=>(bool)$val
        );
        return $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
    }

    private function renderRadio($field, $key, $val, $disabled)
    {
        $data = array(
            'type'=>'radio',
            'field'=>$field,
            'key'=>$key,
            'val'=>$val,
            'disabled'=>$disabled
        );
        return $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
    }

    private function renderSelect($field, $key, $val)
    {
        $data = array(
            'type'=>'select',
            'field'=>$field,
            'key'=>$key,
            'val'=>$val
        );
        return $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
    }

    private function renderTextarea($field, $key, $val, $disabled)
    {
        $data = array(
            'type'=>'textarea',
            'field'=>$field,
            'key'=>$key,
            'val'=>htmlentities($val, ENT_COMPAT, 'UTF-8'),
            'disabled'=>$disabled
        );
        return $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
    }

    private function renderTextField($field, $key, $val, $disabled)
    {
        $data = array(
            'type'=>'textfield',
            'field'=>$field,
            'key'=>$key,
            'val'=>htmlentities($val, ENT_COMPAT, 'UTF-8'),
            'disabled'=>$disabled
        );
        return $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
    }

    private function renderThumb($field)
    {
        $data = array(
            'type'=>'thumb',
            'field'=>$field,
        );
        return $this->twig->render('@ModuleGautoUpgrade/block/formrender.twig', $data);
    }
}
