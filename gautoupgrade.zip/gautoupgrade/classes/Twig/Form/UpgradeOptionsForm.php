<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\Twig\Form;

use PrestaShop\Module\GautoUpgrade\UpgradeTools\Translator;

class UpgradeOptionsForm
{
    /**
     * @var array
     */
    private $fields;

    /**
     * @var Translator
     */
    private $translator;

    /**
     * @var FormRenderer
     */
    private $formRenderer;

    public function __construct(Translator $translator, FormRenderer $formRenderer)
    {
        $this->translator = $translator;
        $this->formRenderer = $formRenderer;

        // TODO: Class const
        $translationDomain = 'Modules.Gautoupgrade.Admin';

        $this->fields = array(
            'PS_GAUTOUP_BACKUP' => array(
                'title' => $this->translator->trans(
                    'Back up my files and database',
                    array(),
                    $translationDomain
                ),
                'cast' => 'intval',
                'validation' => 'isBool',
                'defaultValue' => '1',
                'type' => 'bool',
                'desc' => $this->translator->trans(
                    'Automatically back up your database and files in order to restore your shop if needed. This is experimental: you should still perform your own manual backup for safety.',
                    array(),
                    $translationDomain
                ),
            ),
            'PS_GAUTOUP_KEEP_IMAGES' => array(
                'title' => $this->translator->trans(
                    'Back up my images',
                    array(),
                    $translationDomain
                ),
                'cast' => 'intval',
                'validation' => 'isBool',
                'defaultValue' => '1',
                'type' => 'bool',
                'desc' => $this->translator->trans(
                    'To save time, you can decide not to back your images up. In any case, always make sure you did back them up manually.',
                    array(),
                    $translationDomain
                ),
            ),
            'PS_GAUTOUP_PERFORMANCE' => array(
                'title' => $translator->trans(
                    'Server performance',
                    array(),
                    $translationDomain
                ),
                'cast' => 'intval',
                'validation' => 'isInt',
                'defaultValue' => '1',
                'type' => 'select', 'desc' => $translator->trans(
                        'Unless you are using a dedicated server, select "Low".',
                        array(),
                        $translationDomain
                    ) . ' ' .
                    $translator->trans(
                        'A high value can cause the upgrade to fail if your server is not powerful enough to process the upgrade tasks in a short amount of time.',
                        array(),
                        $translationDomain
                    ),
                'choices' => array(
                    1 => $translator->trans(
                        'Low (recommended)',
                        array(),
                        $translationDomain
                    ),
                    2 => $translator->trans('Medium', array(), $translationDomain),
                    3 => $translator->trans(
                        'High',
                        array(),
                        $translationDomain
                    ),
                ),
            ),
            'PS_GAUTOUP_CUSTOM_MOD_DESACT' => array(
                'title' => $translator->trans(
                    'Disable non-native modules',
                    array(),
                    $translationDomain
                ),
                'cast' => 'intval',
                'validation' => 'isBool',
                'type' => 'bool',
                'desc' => $translator->trans(
                        'As non-native modules can experience some compatibility issues, we recommend to disable them by default.',
                        array(),
                        $translationDomain
                    ) . ' ' .
                    $translator->trans(
                        'Keeping them enabled might prevent you from loading the "Modules" page properly after the upgrade.',
                        array(),
                        $translationDomain
                    ),
            ),
            'PS_GAUTOUP_UPDATE_DEFAULT_THEME' => array(
                'title' => $translator->trans(
                    'Upgrade the default theme',
                    array(),
                    $translationDomain
                ),
                'cast' => 'intval',
                'validation' => 'isBool',
                'defaultValue' => '1',
                'type' => 'bool',
                'desc' => $translator->trans(
                        'If you customized the default PrestaShop theme in its folder (folder name "classic" in 1.7), enabling this option will lose your modifications.',
                        array(),
                        $translationDomain
                    ) . ' '
                    . $translator->trans(
                        'If you are using your own theme, enabling this option will simply update the default theme files, and your own theme will be safe.',
                        array(),
                        $translationDomain
                    ),
            ),

            'PS_GAUTOUP_CHANGE_DEFAULT_THEME' => array(
                'title' => $translator->trans(
                    'Switch to the default theme',
                    array(),
                    $translationDomain
                ),
                'cast' => 'intval',
                'validation' => 'isBool',
                'defaultValue' => '0',
                'type' => 'bool',
                'desc' => $translator->trans(
                    'This will change your theme: your shop will then use the default theme of the version of PrestaShop you are upgrading to.',
                    array(),
                    $translationDomain
                ),
            ),

            'PS_GAUTOUP_KEEP_MAILS' => array(
                'title' => $translator->trans(
                    'Keep the customized email templates',
                    array(),
                    $translationDomain
                ),
                'cast' => 'intval',
                'validation' => 'isBool',
                'type' => 'bool',
                'desc' => $translator->trans(
                        'This will not upgrade the default PrestaShop e-mails.',
                        array(),
                        $translationDomain
                    ) . ' '
                    . $translator->trans(
                        'If you customized the default PrestaShop e-mail templates, enabling this option will keep your modifications.',
                        array(),
                        $translationDomain
                    ),
            ),
        );
    }

    public function render()
    {
        return $this->formRenderer->render(
            'upgradeOptions',
            $this->fields,
            $this->translator->trans(
                'Upgrade Options',
                array(),
                'Modules.Gautoupgrade.Admin'
            ),
            '',
            'prefs'
        );
    }
}
