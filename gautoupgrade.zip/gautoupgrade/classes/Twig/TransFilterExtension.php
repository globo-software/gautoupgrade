<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\Twig;

use Twig_Extension;
use Twig_SimpleFilter;

class TransFilterExtension extends Twig_Extension
{
    const DOMAIN = 'Modules.Gautoupgrade.Admin';

    private $translator;

    public function __construct($translator)
    {
        $this->translator = $translator;
    }

    public function getFilters()
    {
        return array(
            new Twig_SimpleFilter('trans', array($this, 'trans')),
        );
    }

    public function trans($string, $params = array())
    {
        return $this->translator->trans($string, $params, self::DOMAIN);
    }
}
