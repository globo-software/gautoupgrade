<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade;

/**
 * Todo: Should we create a UpgradeWarning class instead of setting the severity here?
 */
class UpgradeException extends \Exception
{
    const SEVERITY_ERROR = 1;
    const SEVERITY_WARNING = 2;

    private $quickInfos = array();

    private $severity = self::SEVERITY_ERROR;

    public function getQuickInfos()
    {
        return $this->quickInfos;
    }

    public function getSeverity()
    {
        return $this->severity;
    }

    public function addQuickInfo($quickInfo)
    {
        $this->quickInfos[] = $quickInfo;

        return $this;
    }

    public function setQuickInfos(array $quickInfos)
    {
        $this->quickInfos = $quickInfos;

        return $this;
    }

    public function setSeverity($severity)
    {
        $this->severity = (int) $severity;

        return $this;
    }
}
