<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner\Miscellaneous;

use PrestaShop\Module\GautoUpgrade\Parameters\UpgradeFileNames;
use PrestaShop\Module\GautoUpgrade\TaskRunner\AbstractTask;

/**
 * List the files modified in the current installation regards to the original version.
 */
class CheckFilesVersion extends AbstractTask
{
    public function run()
    {
        // do nothing after this request (see javascript function doAjaxRequest )
        $this->next = '';
        $upgrader = $this->container->getUpgrader();
        $changedFileList = $upgrader->getChangedFilesList();

        if ($changedFileList === false) {
            $this->nextParams['status'] = 'error';
            $this->nextParams['msg'] = $this->translator->trans('Unable to check files for the installed version of PrestaShop.', array(), 'Modules.Gautoupgrade.Admin');

            return;
        }

        foreach (array('core', 'translation', 'mail') as $type) {
            if (!isset($changedFileList[$type])) {
                $changedFileList[$type] = array();
            }
        }

        if ($upgrader->isAuthenticPrestashopVersion() === true) {
            $this->nextParams['status'] = 'ok';
            $this->nextParams['msg'] = $this->translator->trans('Core files are ok', array(), 'Modules.Gautoupgrade.Admin');
        } else {
            $this->nextParams['status'] = 'warn';
            $this->nextParams['msg'] = $this->translator->trans(
                '%modificationscount% file modifications have been detected, including %coremodifications% from core and native modules:',
                array(
                    '%modificationscount%' => count(array_merge($changedFileList['core'], $changedFileList['mail'], $changedFileList['translation'])),
                    '%coremodifications%' => count($changedFileList['core']),
                ),
                'Modules.Gautoupgrade.Admin'
            );
        }
        $this->nextParams['result'] = $changedFileList;

        $this->container->getFileConfigurationStorage()->save($changedFileList['translation'], UpgradeFileNames::TRANSLATION_FILES_CUSTOM_LIST);
        $this->container->getFileConfigurationStorage()->save($changedFileList['mail'], UpgradeFileNames::MAILS_CUSTOM_LIST);
    }
}
