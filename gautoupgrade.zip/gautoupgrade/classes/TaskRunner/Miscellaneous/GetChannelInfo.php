<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner\Miscellaneous;

use PrestaShop\Module\GautoUpgrade\ChannelInfo;
use PrestaShop\Module\GautoUpgrade\TaskRunner\AbstractTask;
use PrestaShop\Module\GautoUpgrade\Twig\Block\ChannelInfoBlock;

/**
 * display informations related to the selected channel : link/changelog for remote channel,
 * or configuration values for special channels.
 */
class GetChannelInfo extends AbstractTask
{
    public function run()
    {
        // do nothing after this request (see javascript function doAjaxRequest )
        $this->next = '';

        $channel = $this->container->getUpgradeConfiguration()->getChannel();
        $channelInfo = (new ChannelInfo($this->container->getUpgrader(), $this->container->getUpgradeConfiguration(), $channel));
        $channelInfoArray = $channelInfo->getInfo();
        $this->nextParams['result']['available'] = $channelInfoArray['available'];

        $this->nextParams['result']['div'] = (new ChannelInfoBlock(
            $this->container->getUpgradeConfiguration(),
            $channelInfo,
            $this->container->getTwig())
        )->render();
    }
}
