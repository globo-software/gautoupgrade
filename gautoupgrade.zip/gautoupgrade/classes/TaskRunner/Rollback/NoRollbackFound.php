<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner\Rollback;

use PrestaShop\Module\GautoUpgrade\TaskRunner\AbstractTask;

class NoRollbackFound extends AbstractTask
{
    public function run()
    {
        $this->logger->info($this->translator->trans('Nothing to restore', array(), 'Modules.Gautoupgrade.Admin'));
        $this->next = 'rollbackComplete';
    }
}
