<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner\Rollback;

use PrestaShop\Module\GautoUpgrade\TaskRunner\ChainedTasks;

/**
 * Execute the whole upgrade process in a single request.
 */
class AllRollbackTasks extends ChainedTasks
{
    const initialTask = 'rollback';

    protected $step = self::initialTask;

    /**
     * Customize the execution context with several options
     * > action: Replace the initial step to run
     * > channel: Makes a specific upgrade (minor, major etc.)
     * > data: Loads an encoded array of data coming from another request.
     *
     * @param array $options
     */
    public function setOptions(array $options)
    {
        if (!empty($options['backup'])) {
            $this->container->getState()->setRestoreName($options['backup']);
        }
    }

    /**
     * Set default config on first run.
     */
    public function init()
    {
        // Do nothing
    }
}
