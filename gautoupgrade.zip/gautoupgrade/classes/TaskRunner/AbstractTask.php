<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner;

use PrestaShop\Module\GautoUpgrade\AjaxResponse;
use PrestaShop\Module\GautoUpgrade\Log\Logger;
use PrestaShop\Module\GautoUpgrade\UpgradeContainer;

abstract class AbstractTask
{
    /* usage :  key = the step you want to skip
     *               value = the next step you want instead
     *	example : public static $skipAction = array();
     */
    public static $skipAction = array();

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var \PrestaShop\Module\GautoUpgrade\UpgradeTools\Translator
     */
    protected $translator;

    /**
     * @var UpgradeContainer
     */
    protected $container;

    // Task progress details
    protected $stepDone;
    protected $status;
    protected $error;
    protected $nextParams = array();
    protected $next;
    public $totalitem;
    public $leftitem;

    public function __construct(UpgradeContainer $container)
    {
        $this->container = $container;
        $this->logger = $this->container->getLogger();
        $this->translator = $this->container->getTranslator();
        $this->checkTaskMayRun();
    }

    /**
     * @return string base64 encoded data from AjaxResponse
     */
    public function getEncodedResponse()
    {
        //return base64_encode($this->getJsonResponse());
        return $this->getJsonResponse();
    }

    /**
     * @return string Json encoded data from AjaxResponse
     */
    public function getJsonResponse()
    {
        return $this->getResponse()->getJson();
    }

    /**
     * Get result of the task and data to send to the next request.
     *
     * @return AjaxResponse
     */
    public function getResponse()
    {
        $response = new AjaxResponse($this->container->getState(), $this->logger);

        return $response->setError($this->error)
            ->setStepDone($this->stepDone)
            ->setNext($this->next)
            ->setNextParams($this->nextParams)
            ->setUpgradeConfiguration($this->container->getUpgradeConfiguration())
            ->setTotalitem($this->totalitem)
            ->setLeftitem($this->leftitem)
            
            ;
    }

    private function checkTaskMayRun()
    {
        // PrestaShop demo mode
        if (defined('_PS_MODE_DEMO_') && _PS_MODE_DEMO_ == true) {
            return;
        }

        $currentAction = get_class($this);
        if (isset(self::$skipAction[$currentAction])) {
            $this->next = self::$skipAction[$currentAction];
            $this->logger->info($this->translator->trans('Action %s skipped', array($currentAction), 'Modules.Gautoupgrade.Admin'));
        }
    }

    public function init()
    {
        $this->container->initPrestaShopCore();
    }

    abstract public function run();
}
