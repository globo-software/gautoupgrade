<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade;

use PrestaShop\Module\GautoUpgrade\TaskRunner\AbstractTask;

/**
 * Clean the database from unwanted entries.
 */
class CleanDatabase extends AbstractTask
{
    public function run()
    {
        // Clean tabs order
        foreach ($this->container->getDb()->ExecuteS('SELECT DISTINCT id_parent FROM ' . _DB_PREFIX_ . 'tab') as $parent) {
            $i = 1;
            foreach ($this->container->getDb()->ExecuteS('SELECT id_tab FROM ' . _DB_PREFIX_ . 'tab WHERE id_parent = ' . (int) $parent['id_parent'] . ' ORDER BY IF(class_name IN ("AdminHome", "AdminDashboard"), 1, 2), position ASC') as $child) {
                $this->container->getDb()->Execute('UPDATE ' . _DB_PREFIX_ . 'tab SET position = ' . (int) ($i++) . ' WHERE id_tab = ' . (int) $child['id_tab'] . ' AND id_parent = ' . (int) $parent['id_parent']);
            }
        }
        /** fix Access Denied */ 
        $id_profile = _PS_ADMIN_PROFILE_;
        if($id_profile > 0){
            $sql = 'INSERT INTO '._DB_PREFIX_.'access (id_profile, id_authorization_role)
                    SELECT '.(int)$id_profile.',  r.id_authorization_role
                    FROM '._DB_PREFIX_.'authorization_role r
                    LEFT JOIN '._DB_PREFIX_.'access a
                    ON r.id_authorization_role = a.id_authorization_role AND a.id_profile = '.(int)$id_profile.' 
                    WHERE r.slug LIKE \'ROLE_MOD_TAB%\'
                    AND NOT EXISTS(SELECT 1 FROM '._DB_PREFIX_.'access WHERE id_authorization_role = r.id_authorization_role AND id_profile = '.(int)$id_profile.')
                    ORDER BY r.slug';
            $this->container->getDb()->Execute($sql);
        }
        $this->status = 'ok';
        $this->next = 'upgradeComplete';
        $this->logger->info($this->translator->trans('The database has been cleaned.', array(), 'Modules.Gautoupgrade.Admin'));
    }
}
