<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade;

use PrestaShop\Module\GautoUpgrade\UpgradeException;
use PrestaShop\Module\GautoUpgrade\Parameters\UpgradeFileNames;
use PrestaShop\Module\GautoUpgrade\TaskRunner\AbstractTask;
use PrestaShop\Module\GautoUpgrade\UpgradeTools\FilesystemAdapter;
use PrestaShop\Module\GautoUpgrade\UpgradeContainer;

/**
 * Upgrade all partners modules according to the installed prestashop version.
 */
class UpgradeModules extends AbstractTask
{
    public function run()
    {
        $start_time = time();
        
        if (!$this->container->getFileConfigurationStorage()->exists(UpgradeFileNames::MODULES_TO_UPGRADE_LIST)) {
            return $this->warmUp();
        }
        
        $this->next = 'upgradeModules';
        $listModules = $this->container->getFileConfigurationStorage()->load(UpgradeFileNames::MODULES_TO_UPGRADE_LIST);

        if (!is_array($listModules)) {
            $this->next = 'upgradeComplete';
            $this->container->getState()->setWarningExists(true);
            $this->logger->error($this->translator->trans('listModules is not an array. No module has been updated.', array(), 'Modules.Gautoupgrade.Admin'));

            return true;
        }
        $installversion = $this->container->getState()->getInstallVersion();
        $time_elapsed = time() - $start_time;
        $modules_to_delete = array(
            'backwardcompatibility' => 'Backward Compatibility',
            'dibs' => 'Dibs',
            'cloudcache' => 'Cloudcache',
            'mobile_theme' => 'The 1.4 mobile_theme',
            'trustedshops' => 'Trustedshops',
            'dejala' => 'Dejala',
            'stripejs' => 'Stripejs',
            'blockvariouslinks' => 'Block Various Links',
        );
        
        if(version_compare($installversion, '1.7.0.0', '>=')){
            if (!class_exists('ImportModuleCore', false) && !class_exists('ImportModule', false)) {
                if (file_exists(_PS_ROOT_DIR_.'/modules/gautoupgrade/classes/ImportModule.php')) {
                    include_once(_PS_ROOT_DIR_.'/modules/gautoupgrade/classes/ImportModule.php');
                }
            }
            $modules_to_delete['importerosc']='Importer osCommerce';
            $modules_to_delete['shopimporter']='Shop Importer';
        }
        // module list
        if (count($listModules) > 0) {
            do {
                $module_info = array_shift($listModules);
                if(version_compare($installversion, '1.7.0.0', '>=') && isset($modules_to_delete[$module_info['name']])){
                    continue;
                }
                try {
                    $this->logger->debug($this->translator->trans('Upgrading module %module%...', ['%module%' => $module_info['name']], 'Modules.Gautoupgrade.Admin'));
                    $this->container->getModuleAdapter()->upgradeModule($module_info['id'], $module_info['name']);
                    $this->logger->debug($this->translator->trans('The files of module %s have been upgraded.', array($module_info['name']), 'Modules.Gautoupgrade.Admin'));
                } catch (UpgradeException $e) {
                    $this->handleException($e);
                    if ($e->getSeverity() === UpgradeException::SEVERITY_ERROR) {
                        return false;
                    }
                }
                $time_elapsed = time() - $start_time;
            } while (($time_elapsed < $this->container->getUpgradeConfiguration()->getTimePerCall()) && count($listModules) > 0);

            $modules_left = count($listModules);
            $this->leftitem = (int)$modules_left;
            $this->container->getFileConfigurationStorage()->save($listModules, UpgradeFileNames::MODULES_TO_UPGRADE_LIST);
            unset($listModules);

            $this->next = 'upgradeModules'; 
            if ($modules_left) {
                $this->logger->info($this->translator->trans('%s modules left to upgrade.', array($modules_left), 'Modules.Gautoupgrade.Admin'));
            }
            $this->stepDone = false;
        } else {
            foreach ($modules_to_delete as $key => $module) {
                $this->container->getDb()->execute('DELETE ms.*, hm.*
                FROM `' . _DB_PREFIX_ . 'module_shop` ms
                INNER JOIN `' . _DB_PREFIX_ . 'hook_module` hm USING (`id_module`)
                INNER JOIN `' . _DB_PREFIX_ . 'module` m USING (`id_module`)
                WHERE m.`name` LIKE \'' . pSQL($key) . '\'');
                $this->container->getDb()->execute('UPDATE `' . _DB_PREFIX_ . 'module` SET `active` = 0 WHERE `name` LIKE \'' . pSQL($key) . '\'');

                $path = $this->container->getProperty(UpgradeContainer::PS_ROOT_PATH) . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . $key . DIRECTORY_SEPARATOR;
                if (file_exists($path . $key . '.php')) {
                    if (FilesystemAdapter::deleteDirectory($path)) {
                        $this->logger->debug($this->translator->trans(
                            'The %modulename% module is not compatible with version %version%, it will be removed from your FTP.',
                            array(
                                '%modulename%' => $module,
                                '%version%' => $this->container->getState()->getInstallVersion(),
                            ),
                            'Modules.Gautoupgrade.Admin'
                        ));
                    } else {
                        $this->logger->error($this->translator->trans(
                            'The %modulename% module is not compatible with version %version%, please remove it from your FTP.',
                            array(
                                '%modulename%' => $module,
                                '%version%' => $this->container->getState()->getInstallVersion(),
                            ),
                            'Modules.Gautoupgrade.Admin'
                        ));
                    }
                }
            }

            $this->stepDone = true;
            $this->status = 'ok';
            $this->next = 'cleanDatabase';
            $this->logger->info($this->translator->trans('Addons modules files have been upgraded.', array(), 'Modules.Gautoupgrade.Admin'));

            return true;
        }

        return true;
    }

    public function warmUp()
    {
        $modulesToUpgrade = array();
        try {
            $modulesToUpgrade = $this->container->getModuleAdapter()->listModulesToUpgrade($this->container->getState()->getModules_addons());
            $this->container->getFileConfigurationStorage()->save($modulesToUpgrade, UpgradeFileNames::MODULES_TO_UPGRADE_LIST);
        } catch (UpgradeException $e) {
            $this->handleException($e);

            return false;
        }

        $total_modules_to_upgrade = count($modulesToUpgrade);
        $this->leftitem = (int)$total_modules_to_upgrade;
        $this->totalitem =  (int)$this->leftitem;
        if ($total_modules_to_upgrade) {
            $this->logger->info($this->translator->trans('%s modules will be upgraded.', array($total_modules_to_upgrade), 'Modules.Gautoupgrade.Admin'));
        }

        // WamUp core side
        if (method_exists('\Module', 'getModulesOnDisk')) {
            \Module::getModulesOnDisk();
        }

        $this->stepDone = false;
        $this->next = 'upgradeModules';

        return true;
    }

    private function handleException(UpgradeException $e)
    {
        foreach ($e->getQuickInfos() as $log) {
            $this->logger->debug($log);
        }
        if ($e->getSeverity() === UpgradeException::SEVERITY_ERROR) {
            $this->next = 'error';
            $this->error = true;
            $this->logger->error($e->getMessage());
        }
        if ($e->getSeverity() === UpgradeException::SEVERITY_WARNING) {
            $this->logger->warning($e->getMessage());
        }
    }
}
