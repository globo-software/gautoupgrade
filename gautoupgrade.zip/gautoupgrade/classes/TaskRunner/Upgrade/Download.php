<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade;

use PrestaShop\Module\GautoUpgrade\UpgradeContainer;
use PrestaShop\Module\GautoUpgrade\TaskRunner\AbstractTask;
use PrestaShop\Module\GautoUpgrade\UpgradeTools\FilesystemAdapter;

/**
 * Download PrestaShop archive according to the chosen channel.
 */
class Download extends AbstractTask
{
    public function run()
    {
        if (!\ConfigurationTest::test_fopen() && !\ConfigurationTest::test_curl()) {
            $this->logger->error($this->translator->trans('You need allow_url_fopen or cURL enabled for automatic download to work. You can also manually upload it in filepath %s.', array($this->container->getFilePath()), 'Modules.Gautoupgrade.Admin'));
            $this->next = 'error';

            return;
        }

        $upgrader = $this->container->getUpgrader();
        // regex optimization
        preg_match('#([0-9]+\.[0-9]+)(?:\.[0-9]+){1,2}#', _PS_VERSION_, $matches);
        $upgrader->channel = $this->container->getUpgradeConfiguration()->get('channel');
        $upgrader->branch = $matches[1];
        if ($this->container->getUpgradeConfiguration()->get('channel') == 'private' && !$this->container->getUpgradeConfiguration()->get('private_allow_major')) {
            $upgrader->checkPSVersion(false, array('private', 'minor'));
        } else {
            $upgrader->checkPSVersion(false, array('minor'));
        }

        if ($upgrader->channel == 'private') {
            $upgrader->link = $this->container->getUpgradeConfiguration()->get('private_release_link');
            $upgrader->md5 = $this->container->getUpgradeConfiguration()->get('private_release_md5');
        }
        $this->logger->debug($this->translator->trans('Downloading from %s', array($upgrader->link), 'Modules.Gautoupgrade.Admin'));
        $this->logger->debug($this->translator->trans('File will be saved in %s', array($this->container->getFilePath()), 'Modules.Gautoupgrade.Admin'));
        if (file_exists($this->container->getProperty(UpgradeContainer::DOWNLOAD_PATH))) {
            FilesystemAdapter::deleteDirectory($this->container->getProperty(UpgradeContainer::DOWNLOAD_PATH), false);
            $this->logger->debug($this->translator->trans('Download directory has been emptied', array(), 'Modules.Gautoupgrade.Admin'));
        }
        $report = '';
        $relative_download_path = str_replace(_PS_ROOT_DIR_, '', $this->container->getProperty(UpgradeContainer::DOWNLOAD_PATH));
        if (\ConfigurationTest::test_dir($relative_download_path, false, $report)) {
            $res = $upgrader->downloadLast($this->container->getProperty(UpgradeContainer::DOWNLOAD_PATH), $this->container->getProperty(UpgradeContainer::ARCHIVE_FILENAME));
            if ($res) {
                $md5file = md5_file(realpath($this->container->getProperty(UpgradeContainer::ARCHIVE_FILEPATH)));
                if ($md5file == $upgrader->md5) {
                    $this->next = 'unzip';
                    $this->logger->debug($this->translator->trans('Download complete.', array(), 'Modules.Gautoupgrade.Admin'));
                    $this->logger->info($this->translator->trans('Download complete. Now extracting...', array(), 'Modules.Gautoupgrade.Admin'));
                } else {
                    $this->logger->error($this->translator->trans('Download complete but MD5 sum does not match (%s).', array($md5file), 'Modules.Gautoupgrade.Admin'));
                    $this->logger->info($this->translator->trans('Download complete but MD5 sum does not match (%s). Operation aborted.', array($md5file), 'Modules.Gautoupgrade.Admin'));
                    $this->next = 'error';
                }
            } else {
                if ($upgrader->channel == 'private') {
                    $this->logger->error($this->translator->trans('Error during download. The private key may be incorrect.', array(), 'Modules.Gautoupgrade.Admin'));
                } else {
                    $this->logger->error($this->translator->trans('Error during download', array(), 'Modules.Gautoupgrade.Admin'));
                }
                $this->next = 'error';
            }
        } else {
            $this->logger->error($this->translator->trans('Download directory %s is not writable.', array($this->container->getProperty(UpgradeContainer::DOWNLOAD_PATH)), 'Modules.Gautoupgrade.Admin'));
            $this->next = 'error';
        }
    }
}
