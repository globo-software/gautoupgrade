<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade;

use PrestaShop\Module\GautoUpgrade\TaskRunner\AbstractTask;
use PrestaShop\Module\GautoUpgrade\UpgradeTools\FilesystemAdapter;
use PrestaShop\Module\GautoUpgrade\UpgradeContainer;
use Configuration;

/**
 * Ends the upgrade process and displays the success message.
 */
class UpgradeComplete extends AbstractTask
{
    public function run()
    {
        $this->logger->info($this->container->getState()->getWarningExists() ?
            $this->translator->trans('Upgrade process done, but some warnings have been found.', array(), 'Modules.Gautoupgrade.Admin') :
            $this->translator->trans('Upgrade process done. Congratulations! You can now reactivate your shop.', array(), 'Modules.Gautoupgrade.Admin')
        );

        $this->next = '';

        if ($this->container->getUpgradeConfiguration()->get('channel') != 'archive' && file_exists($this->container->getFilePath()) && unlink($this->container->getFilePath())) {
            $this->logger->debug($this->translator->trans('%s removed', array($this->container->getFilePath()), 'Modules.Gautoupgrade.Admin'));
        } elseif (is_file($this->container->getFilePath())) {
            $this->logger->debug($this->translator->trans('Please remove %s by FTP', array($this->container->getFilePath()), 'Modules.Gautoupgrade.Admin'));
        }

        if ($this->container->getUpgradeConfiguration()->get('channel') != 'directory' && file_exists($this->container->getProperty(UpgradeContainer::LATEST_PATH)) && FilesystemAdapter::deleteDirectory($this->container->getProperty(UpgradeContainer::LATEST_PATH))) {
            $this->logger->debug($this->translator->trans('%s removed', array($this->container->getProperty(UpgradeContainer::LATEST_PATH)), 'Modules.Gautoupgrade.Admin'));
        } elseif (is_dir($this->container->getProperty(UpgradeContainer::LATEST_PATH))) {
            $this->logger->debug($this->translator->trans('Please remove %s by FTP', array($this->container->getProperty(UpgradeContainer::LATEST_PATH)), 'Modules.Gautoupgrade.Admin'));
        }

        // Reinit config
        Configuration::deleteByName('PS_GAUTOUP_IGNORE_REQS');
        Configuration::deleteByName('G_INSTALL_BRANCH');
        // removing temporary files
        $this->container->getFileConfigurationStorage()->cleanAll();
    }
}
