<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade;

use PrestaShop\Module\GautoUpgrade\TaskRunner\AbstractTask;
use Symfony\Component\Filesystem\Filesystem;
use PrestaShop\Module\GautoUpgrade\UpgradeContainer;
use PrestaShop\Module\GautoUpgrade\UpgradeTools\FilesystemAdapter;

/**
 * extract chosen version into $this->upgradeClass->latestPath directory.
 */
class Unzip extends AbstractTask
{
    public function run()
    {
        $filepath = $this->container->getFilePath();
        $destExtract = $this->container->getProperty(UpgradeContainer::LATEST_PATH);

        if (file_exists($destExtract)) {
            FilesystemAdapter::deleteDirectory($destExtract, false);
            $this->logger->debug($this->translator->trans('"/latest" directory has been emptied', array(), 'Modules.Gautoupgrade.Admin'));
        }
        $relative_extract_path = str_replace(_PS_ROOT_DIR_, '', $destExtract);
        $report = '';
        if (!\ConfigurationTest::test_dir($relative_extract_path, false, $report)) {
            $this->logger->error($this->translator->trans('Extraction directory %s is not writable.', array($destExtract), 'Modules.Gautoupgrade.Admin'));
            $this->next = 'error';
            $this->error = true;

            return false;
        }

        $res = $this->container->getZipAction()->extract($filepath, $destExtract);

        if (!$res) {
            $this->next = 'error';
            $this->error = true;
            $this->logger->info($this->translator->trans(
                'Unable to extract %filepath% file into %destination% folder...',
                array(
                    '%filepath%' => $filepath,
                    '%destination%' => $destExtract,
                ),
                'Modules.Gautoupgrade.Admin'
            ));

            return false;
        }

        // From PrestaShop 1.7, we zip all the files in another package
        // which must be unzipped too
        $newZip = $destExtract . DIRECTORY_SEPARATOR . 'prestashop.zip';
        if (file_exists($newZip)) {
            @unlink($destExtract . DIRECTORY_SEPARATOR . '/index.php');
            @unlink($destExtract . DIRECTORY_SEPARATOR . '/Install_PrestaShop.html');

            $subRes = $this->container->getZipAction()->extract($newZip, $destExtract);
            if (!$subRes) {
                $this->next = 'error';
                $this->logger->info($this->translator->trans(
                    'Unable to extract %filepath% file into %destination% folder...',
                    array(
                        '%filepath%' => $filepath,
                        '%destination%' => $destExtract,
                    ),
                    'Modules.Gautoupgrade.Admin'
                ));

                return false;
            }
        } else {
            $filesystem = new Filesystem();
            $zipSubfolder = $destExtract . '/prestashop/';
            if (!is_dir($zipSubfolder)) {
                $this->next = 'error';
                $this->logger->error(
                    $this->translator->trans('No prestashop/ folder found in the ZIP file. Aborting.', array(), 'Modules.Gautoupgrade.Admin'));

                return;
            }
            // /!\ On PS 1.6, files are unzipped in a subfolder PrestaShop
            foreach (scandir($zipSubfolder) as $file) {
                if ($file[0] === '.') {
                    continue;
                }
                $filesystem->rename($zipSubfolder . $file, $destExtract . '/' . $file);
            }
        }

        // Unsetting to force listing
        $this->container->getState()->setRemoveList(null);
        $this->next = 'removeSamples';
        $this->logger->info($this->translator->trans('File extraction complete. Removing sample files...', array(), 'Modules.Gautoupgrade.Admin'));

        @unlink($newZip);

        return true;
    }
}
