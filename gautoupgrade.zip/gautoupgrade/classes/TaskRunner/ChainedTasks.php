<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner;

use PrestaShop\Module\GautoUpgrade\AjaxResponse;
use PrestaShop\Module\GautoUpgrade\UpgradeTools\TaskRepository;

/**
 * Execute the whole process in a single request, useful in CLI.
 */
abstract class ChainedTasks extends AbstractTask
{
    protected $step;

    /**
     * Execute all the tasks from a specific initial step, until the end (complete or error).
     *
     * @return int Return code (0 for success, any value otherwise)
     */
    public function run()
    {
        $requireRestart = false;
        while ($this->canContinue() && !$requireRestart) {
            $this->logger->info('=== Step ' . $this->step);
            $controller = TaskRepository::get($this->step, $this->container);
            $controller->init();
            $controller->run();

            $result = $controller->getResponse();
            $requireRestart = $this->checkIfRestartRequested($result);
            $this->error = $result->getError();
            $this->stepDone = $result->getStepDone();
            $this->step = $result->getNext();
        }

        return (int) ($this->error || $this->step === 'error');
    }

    /**
     * Customize the execution context with several options.
     *
     * @param array $options
     */
    abstract public function setOptions(array $options);

    /**
     * Tell the while loop if it can continue.
     *
     * @return bool
     */
    protected function canContinue()
    {
        if (empty($this->step)) {
            return false;
        }

        if ($this->error) {
            return false;
        }

        return $this->step !== 'error';
    }

    /**
     * For some steps, we may require a new request to be made.
     * Return true for stopping the process.
     */
    protected function checkIfRestartRequested(AjaxResponse $response)
    {
        $response;
        return false;
    }
}
