<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\TaskRunner;

class NullTask extends AbstractTask
{
    public function run()
    {
        // Nothing
    }
}
