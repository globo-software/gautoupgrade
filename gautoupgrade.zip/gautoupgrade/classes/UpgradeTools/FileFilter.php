<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\UpgradeTools;

use PrestaShop\Module\GautoUpgrade\Parameters\UpgradeConfiguration;

class FileFilter
{
    /**
     * @var UpgradeConfiguration
     */
    protected $configuration;

    /**
     * @var string Gautoupgrade sub directory*
     */
    protected $gautoupgradeDir;

    public function __construct(UpgradeConfiguration $configuration, $gautoupgradeDir = 'gautoupgrade')
    {
        $this->configuration = $configuration;
        $this->gautoupgradeDir = $gautoupgradeDir;
    }

    /**
     * AdminGSelfUpgrade::backupIgnoreAbsoluteFiles.
     *
     * @return array
     */
    public function getFilesToIgnoreOnBackup()
    {
        // during backup, do not save
        $backupIgnoreAbsoluteFiles = array(
            '/app/cache',
            '/cache/smarty/compile',
            '/cache/smarty/cache',
            '/cache/tcpdf',
            '/cache/cachefs',
            '/var/cache',

            // do not care about the two gautoupgrade dir we use;
            '/modules/gautoupgrade',
            '/admin/gautoupgrade',
        );

        if (!$this->configuration->shouldBackupImages()) {
            $backupIgnoreAbsoluteFiles[] = '/img';
        } else {
            $backupIgnoreAbsoluteFiles[] = '/img/tmp';
        }

        return $backupIgnoreAbsoluteFiles;
    }

    /**
     * AdminGSelfUpgrade::restoreIgnoreAbsoluteFiles.
     *
     * @return array
     */
    public function getFilesToIgnoreOnRestore()
    {
        $restoreIgnoreAbsoluteFiles = array(
            '/app/config/parameters.php',
            '/app/config/parameters.yml',
            '/modules/gautoupgrade',
            '/admin/gautoupgrade',
            '.',
            '..',
        );

        if (!$this->configuration->shouldBackupImages()) {
            $restoreIgnoreAbsoluteFiles[] = '/img';
        } else {
            $restoreIgnoreAbsoluteFiles[] = '/img/tmp';
        }

        return $restoreIgnoreAbsoluteFiles;
    }

    /**
     * AdminGSelfUpgrade::excludeAbsoluteFilesFromUpgrade.
     *
     * @return array
     */
    public function getFilesToIgnoreOnUpgrade()
    {
        // do not copy install, neither app/config/parameters.php in case it would be present
        $excludeAbsoluteFilesFromUpgrade = array(
            '/app/config/parameters.php',
            '/app/config/parameters.yml',
            '/install',
            '/install-dev',
        );

        // this will exclude gautoupgrade dir from admin, and gautoupgrade from modules
        // If set to false, we need to preserve the default themes
        if (!$this->configuration->shouldUpdateDefaultTheme()) {
            $excludeAbsoluteFilesFromUpgrade[] = '/themes/classic';
            $excludeAbsoluteFilesFromUpgrade[] = '/themes/default-bootstrap';
        }

        return $excludeAbsoluteFilesFromUpgrade;
    }

    /**
     * AdminGSelfUpgrade::backupIgnoreFiles
     * AdminGSelfUpgrade::excludeFilesFromUpgrade
     * AdminGSelfUpgrade::restoreIgnoreFiles.
     *
     * These files are checked in every subfolder of the directory tree and can match
     * several time, while the others are only matching a file from the project root.
     *
     * @return array
     */
    public function getExcludeFiles()
    {
        return array(
            '.',
            '..',
            '.svn',
            '.git',
            $this->gautoupgradeDir,
        );
    }
}
