<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\UpgradeTools;

use Db;

class Database
{
    private $db;

    public function __construct(Db $db)
    {
        $this->db = $db;
    }

    public function getAllTables()
    {
        $tables = $this->db->executeS('SHOW TABLES LIKE "' . _DB_PREFIX_ . '%"', true, false);

        $all_tables = array();
        foreach ($tables as $v) {
            $table = array_shift($v);
            $all_tables[$table] = $table;
        }

        return $all_tables;
    }

    /**
     * ToDo: Send tables list instead.
     */
    public function cleanTablesAfterBackup(array $tablesToClean)
    {
        foreach ($tablesToClean as $table) {
            $this->db->execute('DROP TABLE IF EXISTS `' . bqSql($table) . '`');
            $this->db->execute('DROP VIEW IF EXISTS `' . bqSql($table) . '`');
        }
        $this->db->execute('SET FOREIGN_KEY_CHECKS=1');
    }
}
