<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\UpgradeTools;

/**
 * TODO: Create a class for 1.7 env and another one for 1.6 ?
 */
class SymfonyAdapter
{
    /**
     * @var string Version on which PrestaShop is being upgraded
     */
    private $destinationPsVersion;

    public function __construct($destinationPsVersion)
    {
        $this->destinationPsVersion = $destinationPsVersion;
    }

    public function runSchemaUpgradeCommand()
    {
        if (version_compare($this->destinationPsVersion, '1.7.1.1', '>=')) {
            $schemaUpgrade = new \PrestaShopBundle\Service\Database\Upgrade();
            $outputCommand = 'prestashop:schema:update-without-foreign';
        } else {
            $schemaUpgrade = new \PrestaShopBundle\Service\Cache\Refresh();
            $outputCommand = 'doctrine:schema:update';
        }

        $schemaUpgrade->addDoctrineSchemaUpdate();
        $output = $schemaUpgrade->execute();

        return $output[$outputCommand];
    }

    /**
     * Return the AppKernel, after initialization
     *
     * @return \AppKernel
     */
    public function initAppKernel()
    {
        global $kernel; /* fix bug ""Kernel Container is not available" in ps 1.7.6.x */
        if (!$kernel instanceof \AppKernel || !$kernel || null === $kernel) {
            require_once _PS_ROOT_DIR_ . '/app/AppKernel.php';
            $env = (true == _PS_MODE_DEV_) ? 'dev' : 'prod';
            $kernel = new \AppKernel($env, _PS_MODE_DEV_);
            $kernel->loadClassCache();
            $kernel->boot();
        }

        return $kernel;
    }
}
