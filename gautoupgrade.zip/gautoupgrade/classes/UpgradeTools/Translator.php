<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\UpgradeTools;

class Translator
{
    private $caller;

    public function __construct($caller)
    {
        $this->caller = $caller;
    }

    /**
     * Translate a string to the current language.
     *
     * This methods has the same signature as the 1.7 trans method, but only relies
     *  on the module translation files.
     *
     * @param string $id Original text
     * @param array $parameters Parameters to apply
     * @param string $domain Unused
     * @param string $locale Unused
     *
     * @return string Translated string with parameters applied
     */
    public function trans($id, array $parameters = array(), $domain = 'Modules.Gautoupgrade.Admin', $locale = null)
    {
        $domain;$locale;
        // If PrestaShop core is not instancied properly, do not try to translate
        if (!method_exists('\Context', 'getContext') || null === \Context::getContext()->language) {
            return $this->applyParameters($id, $parameters);
        }

        if (method_exists('\Translate', 'getModuleTranslation')) {
            $translated = \Translate::getModuleTranslation('gautoupgrade', $id, $this->caller, null);
            if (!count($parameters)) {
                return $translated;
            }
        } else {
            $translated = $id;
        }

        return $this->applyParameters($translated, $parameters);
    }

    /**
     * @param string $id
     * @param array $parameters
     *
     * @return string Translated string with parameters applied
     *
     * @internal Public for tests
     */
    public function applyParameters($id, array $parameters = array())
    {
        // Replace placeholders for non numeric keys
        foreach ($parameters as $placeholder => $value) {
            if (is_int($placeholder)) {
                continue;
            }
            $id = str_replace($placeholder, $value, $id);
            unset($parameters[$placeholder]);
        }

        return call_user_func_array('sprintf', array_merge(array($id), $parameters));
    }
}
