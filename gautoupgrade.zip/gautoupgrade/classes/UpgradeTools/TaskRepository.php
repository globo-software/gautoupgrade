<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\UpgradeTools;

use PrestaShop\Module\GautoUpgrade\UpgradeContainer;

class TaskRepository
{
    public static function get($step, UpgradeContainer $container)
    {
        switch ($step) {
            // MISCELLANEOUS (upgrade configuration, checks etc.)
            case 'checkFilesVersion':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Miscellaneous\CheckFilesVersion($container);
            case 'compareReleases':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Miscellaneous\CompareReleases($container);
            case 'getChannelInfo':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Miscellaneous\GetChannelInfo($container);
            case 'updateConfig':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Miscellaneous\UpdateConfig($container);

            // ROLLBACK
            case 'noRollbackFound':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Rollback\NoRollbackFound($container);
            case 'restoreDb':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Rollback\RestoreDb($container);
            case 'restoreFiles':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Rollback\RestoreFiles($container);
            case 'rollback':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Rollback\Rollback($container);
            case 'rollbackComplete':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Rollback\RollbackComplete($container);

            // UPGRADE
            case 'backupDb':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\BackupDb($container);
            case 'backupFiles':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\BackupFiles($container);
            case 'cleanDatabase':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\CleanDatabase($container);
            case 'download':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\Download($container);
            case 'removeSamples':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\RemoveSamples($container);
            case 'upgradeComplete':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\UpgradeComplete($container);
            case 'upgradeDb':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\UpgradeDb($container);
            case 'upgradeFiles':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\UpgradeFiles($container);
            case 'upgradeModules':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\UpgradeModules($container);
            case 'upgradeNow':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\UpgradeNow($container);
            case 'unzip':
                return new \PrestaShop\Module\GautoUpgrade\TaskRunner\Upgrade\Unzip($container);
        }
        error_log('Unknown step ' . $step);

        return new \PrestaShop\Module\GautoUpgrade\TaskRunner\NullTask($container);
    }
}
