<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\UpgradeTools;

use PrestaShop\Module\GautoUpgrade\UpgradeException;
use PrestaShop\Module\GautoUpgrade\Log\LoggerInterface;
use Symfony\Component\Filesystem\Filesystem;
use PrestaShop\Module\GautoUpgrade\LoggedEvent;
use PrestaShop\Module\GautoUpgrade\Tools14;

class SettingsFileWriter
{
    private $translator;

    public function __construct($translator)
    {
        $this->translator = $translator;
    }

    public function migrateSettingsFile(LoggerInterface $logger)
    {
        if (class_exists('\PrestaShopBundle\Install\Upgrade')) {
            \PrestaShopBundle\Install\Upgrade::migrateSettingsFile(new LoggedEvent($logger));
        }
    }

    /**
     * @param string $filePath
     * @param array $data
     *
     * @throws UpgradeException
     */
    public function writeSettingsFile($filePath, $data)
    {
        if (!is_writable($filePath)) {
            throw new UpgradeException($this->translator->trans('Error when opening settings.inc.php file in write mode', array(), 'Modules.Gautoupgrade.Admin'));
        }

        // Create backup file
        $filesystem = new Filesystem();
        $filesystem->copy($filePath, $filePath . '.bck');

        $fd = fopen($filePath, 'w');
        fwrite($fd, '<?php' . PHP_EOL);
        foreach ($data as $name => $value) {
            if (false === fwrite($fd, "define('$name', '{$this->checkString($value)}');" . PHP_EOL)) {
                throw new UpgradeException($this->translator->trans('Error when generating new settings.inc.php file.', array(), 'Modules.Gautoupgrade.Admin'));
            }
        }
        fclose($fd);
    }

    public function checkString($string)
    {
        if (get_magic_quotes_gpc()) {
            $string = Tools14::stripslashes($string);
        }
        if (!is_numeric($string)) {
            $string = addslashes($string);
            $string = str_replace(array("\n", "\r"), '', $string);
        }

        return $string;
    }
}
