<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

use PrestaShop\PrestaShop\Adapter\Entity\Language;
use PrestaShopBundle\Install\LanguageList;
use PrestaShopBundle\Install\XmlLoader;

/**
 * Migrate BO tabs for 1.7 (new reorganization of BO)
 */
function migrate_tabs_17()
{
    include_once _PS_INSTALL_PATH_.'upgrade/php/add_new_tab.php';

    /* first make some room for new tabs */
    $moduleTabs = Db::getInstance()->executeS(
        'SELECT id_parent FROM '._DB_PREFIX_.'tab WHERE module IS NOT NULL AND module != "" ORDER BY id_tab ASC'
    );

    $moduleParents = array();

    foreach ($moduleTabs as $tab) {
        $idParent = $tab['id_parent'];
        $moduleParents[$idParent] = Db::getInstance()->getValue('SELECT class_name FROM '._DB_PREFIX_.'tab WHERE id_tab='.(int)$idParent);
    }

    /* delete the old structure */
    Db::getInstance()->execute(
        'DELETE t, tl FROM '._DB_PREFIX_.'tab t JOIN '._DB_PREFIX_.'tab_lang tl ON (t.id_tab=tl.id_tab) WHERE module IS NULL OR module = ""'
    );

    $defaultLanguage = new Language((int)Configuration::get('PS_LANG_DEFAULT'));

    $languageList = LanguageList::getInstance();
    $languageList->setLanguage($defaultLanguage->iso_code);

    /* insert the new structure */
    ProfileCore::resetCacheAccesses();
    LanguageCore::resetCache();
    if (!populateTab()) {
        return false;
    }

    /* update remaining idParent */
    foreach($moduleParents as $idParent => $className) {
        $idTab = Db::getInstance()->getValue('SELECT id_tab FROM '._DB_PREFIX_.'tab WHERE class_name='.pSQL($className));
        Db::getInstance()->execute('UPDATE '._DB_PREFIX_.'tab SET id_parent='.(int)$idTab.' WHERE id_parent='.(int)$idParent);
    }

    return true;
}

function populateTab()
{
    $languages = [];
    foreach (Language::getLanguages() as $lang) {
        $languages[$lang['id_lang']] = $lang['iso_code'];
    }

    $xml_loader = new \XmlLoader1700();
    $xml_loader->setTranslator(Context::getContext()->getTranslator());
    $xml_loader->setLanguages($languages);

    try {
        $xml_loader->populateEntity('tab');
    } catch (PrestashopInstallerException $e) {
        return false;
    }

    return true;
}

class XmlLoader1700 extends XmlLoader
{
    public function createEntityTab($identifier, array $data, array $data_lang): void
    {
        if (isset($data['enabled'])) {
            unset($data['enabled']);
        }
        parent::createEntityTab($identifier, $data, $data_lang);
    }
}
