<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

function add_new_status_stock()
{
    Language::resetCache();
    $translator = Context::getContext()->getTranslator();
    $languages  = Language::getLanguages();

    // insert ps_tab AdminStockManagement
    $count = (int)Db::getInstance()->getValue(
        'SELECT count(id_tab) FROM `' . _DB_PREFIX_ . 'tab` 
        WHERE `class_name` = \'AdminStockManagement\'
        AND `id_parent` = 9'
    );
    if (!$count) {
        Db::getInstance()->execute(
            'INSERT INTO `' . _DB_PREFIX_ . 'tab`
            (`id_tab`, `id_parent`, `position`, `module`, `class_name`, `active`, `hide_host_mode`, `icon`)
            VALUES (null, 9, 7, NULL, \'AdminStockManagement\', 1, 0, \'\')'
        );
        $lastIdTab = (int)Db::getInstance()->Insert_ID();

        // ps_tab_lang
        foreach ($languages as $lang) {
            $idLang    = (int)$lang['id_lang'];
            $stockName = $translator->trans(
                    'Stock',
                    array(),
                    'Admin.Navigation.Menu',
                    $lang['locale']
                );
            Db::getInstance()->execute(
                "INSERT INTO `" . _DB_PREFIX_ . "tab_lang` (`id_tab`, `id_lang`, `name`) 
                VALUES (
                  " . (int)$lastIdTab . ", 
                  " . (int)$idLang . ", 
                  '" . pSQL($stockName) . "'
                )"
            );
        }
    }

    // Stock movements
    $data = array(
        array(
            'name' => 'Customer Order',
            'sign' => 1,
            'conf' => 'PS_STOCK_CUSTOMER_ORDER_CANCEL_REASON',
        ),
        array(
            'name' => 'Product Return',
            'sign' => 1,
            'conf' => 'PS_STOCK_CUSTOMER_RETURN_REASON',
        ),
        array(
            'name' => 'Employee Edition',
            'sign' => 1,
            'conf' => 'PS_STOCK_MVT_INC_EMPLOYEE_EDITION',
        ),
        array(
            'name' => 'Employee Edition',
            'sign' => -1,
            'conf' => 'PS_STOCK_MVT_DEC_EMPLOYEE_EDITION',
        ),
    );

    foreach ($data as $d) {
        // We don't want duplicated data
        if (configuration_exists($d['conf'])) {
            continue;
        }

        // ps_stock_mvt_reason
        Db::getInstance()->execute(
            'INSERT INTO `' . _DB_PREFIX_ . 'stock_mvt_reason` (`sign`, `date_add`, `date_upd`, `deleted`)
            VALUES (' . pSQL($d['sign']) . ', NOW(), NOW(), "0")'
        );

        // ps_configuration
        $lastInsertedId = Db::getInstance()->Insert_ID();
        Db::getInstance()->execute(
            'INSERT INTO `' . _DB_PREFIX_ . 'configuration` (`name`, `value`, `date_add`, `date_upd`)
            VALUES ("' . pSQL($d['conf']) . '", ' . (int)$lastInsertedId . ', NOW(), NOW())'
        );

        // ps_stock_mvt_reason_lang
        foreach ($languages as $lang) {
            $mvtName = pSQL(
                $translator->trans(
                    $d['name'],
                    array(),
                    'Admin.Catalog.Feature',
                    $lang['locale']
                )
            );
            Db::getInstance()->execute(
                'INSERT INTO `' . _DB_PREFIX_ . 'stock_mvt_reason_lang` (`id_stock_mvt_reason`, `id_lang`, `name`)
                VALUES (' . (int)$lastInsertedId . ', ' . (int)$lang['id_lang'] . ', "' . pSQL($mvtName) . '")'
            );
        }
    }

    // sync all stock
    $shops = Shop::getShops();
    foreach ($shops as $shop) {
        (new \PrestaShop\PrestaShop\Adapter\StockManager())->updatePhysicalProductQuantity(
            (int)$shop['id_shop'],
            (int)Configuration::get('PS_OS_ERROR'),
            (int)Configuration::get('PS_OS_CANCELED')
        );
    }
}

function configuration_exists($confName)
{
    $count = (int)Db::getInstance()->getValue(
        'SELECT count(id_configuration)
        FROM `' . _DB_PREFIX_ . 'configuration` 
        WHERE `name` = \'' . pSQL($confName) . '\''
    );

    return $count > 0;
}
