<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade\Parameters;

use PrestaShop\Module\GautoUpgrade\Upgrader;

class UpgradeConfigurationStorage extends FileConfigurationStorage
{
    /**
     * UpgradeConfiguration loader.
     *
     * @param string $configFileName
     *
     * @return \PrestaShop\Module\GautoUpgrade\Parameters\UpgradeConfiguration
     */
    public function load($configFileName = '')
    {
        $data = array_merge(
            $this->getDefaultData(),
            parent::load($configFileName)
        );

        return new UpgradeConfiguration($data);
    }

    /**
     * @param \PrestaShop\Module\GautoUpgrade\Parameters\UpgradeConfiguration $config
     * @param string $configFileName Destination path of the config file
     *
     * @return bool
     */
    public function save($config, $configFileName)
    {
        if (!$config instanceof UpgradeConfiguration) {
            throw new \InvalidArgumentException('Config is not a instance of UpgradeConfiguration');
        }

        return parent::save($config->toArray(), $configFileName);
    }

    public function getDefaultData()
    {
        return array(
            'PS_GAUTOUP_PERFORMANCE' => 1,
            'PS_GAUTOUP_CUSTOM_MOD_DESACT' => 1,
            'PS_GAUTOUP_UPDATE_DEFAULT_THEME' => 1,
            'PS_GAUTOUP_CHANGE_DEFAULT_THEME' => 0,
            'PS_GAUTOUP_KEEP_MAILS' => 0,
            'PS_GAUTOUP_BACKUP' => 1,
            'PS_GAUTOUP_KEEP_IMAGES' => 1,
            'channel' => Upgrader::DEFAULT_CHANNEL,
            'archive.filename' => Upgrader::DEFAULT_FILENAME,
        );
    }
}
