<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade;

use PrestaShop\Module\GautoUpgrade\Log\LoggerInterface;

class Workspace
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var UpgradeTools\Translator
     */
    private $translator;

    /**
     * @var array List of paths used by gautoupgrade
     */
    private $paths;

    public function __construct(LoggerInterface $logger, $translator, array $paths)
    {
        $this->logger = $logger;
        $this->translator = $translator;
        $this->paths = $paths;
    }

    public function createFolders()
    {
        foreach ($this->paths as $path) {
            if (!file_exists($path) && !mkdir($path)) {
                $this->logger->error($this->translator->trans('Unable to create directory %s', array($path), 'Modules.Gautoupgrade.Admin'));
            }
            if (!is_writable($path)) {
                $this->logger->error($this->translator->trans('Unable to write in the directory "%s"', array($path), 'Modules.Gautoupgrade.Admin'));
            }
        }
    }
}
