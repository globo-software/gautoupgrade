<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

namespace PrestaShop\Module\GautoUpgrade;

use PrestaShop\Module\GautoUpgrade\Parameters\UpgradeConfiguration;

class ChannelInfo
{
    private $info = array();

    /**
     * @var string
     */
    private $channel;

    /**
     * ChannelInfo constructor.
     *
     * @param Upgrader $upgrader
     * @param UpgradeConfiguration $config
     * @param string $channel
     */
    public function __construct(Upgrader $upgrader, UpgradeConfiguration $config, $channel)
    {
        $this->channel = $channel;
        $publicChannels = array('minor', 'major', 'rc', 'beta', 'alpha');

        preg_match('#([0-9]+\.[0-9]+)(?:\.[0-9]+){1,2}#', _PS_VERSION_, $matches);
        $upgrader->branch = $matches[1];
        $upgrader->channel = $channel;

        if (in_array($channel, $publicChannels)) {
            if ($channel == 'private' && !$config->get('private_allow_major')) {
                $upgrader->checkPSVersion(false, array('private', 'minor'));
            } else {
                $upgrader->checkPSVersion(false, array('minor'));
            }

            $this->info = array(
                'branch' => $upgrader->branch,
                'available' => $upgrader->available,
                'version_num' => $upgrader->version_num,
                'version_name' => $upgrader->version_name,
                'link' => $upgrader->link,
                'md5' => $upgrader->md5,
                'changelog' => $upgrader->changelog,
            );

            return;
        }

        switch ($channel) {
            case 'private':
                if (!$config->get('private_allow_major')) {
                    $upgrader->checkPSVersion(false, array('private', 'minor'));
                } else {
                    $upgrader->checkPSVersion(false, array('minor'));
                }

                $this->info = array(
                    'available' => $upgrader->available,
                    'branch' => $upgrader->branch,
                    'version_num' => $upgrader->version_num,
                    'version_name' => $upgrader->version_name,
                    'link' => $config->get('private_release_link'),
                    'md5' => $config->get('private_release_md5'),
                    'changelog' => $upgrader->changelog,
                );
                break;

            case 'archive':
            case 'directory':
                $this->info = array(
                    'available' => true,
                );
                break;
        }
    }

    /**
     * @return array
     */
    public function getInfo()
    {
        return $this->info;
    }

    /**
     * @return string
     */
    public function getChannel()
    {
        return $this->channel;
    }
}
