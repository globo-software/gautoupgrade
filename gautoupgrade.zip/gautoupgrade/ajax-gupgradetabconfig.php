<?php
/**
* Do not edit the file if you want to upgrade the module in future.
*
* @author    Globo Software Solution JSC <contact@globosoftware.net>
* @copyright  2020 Globo., Jsc
* @license   please read license in file license.txt
* @link	     http://www.globosoftware.net
*/

use PrestaShop\Module\GautoUpgrade\Tools14;

if (function_exists('date_default_timezone_set')) {
    // date_default_timezone_get calls date_default_timezone_set, which can provide warning
    $timezone = @date_default_timezone_get();
    date_default_timezone_set($timezone);
}

/**
 * Set constants & general values used by the gautoupgrade.
 *
 * @param string $callerFilePath Path to the caller file. Needed as the two files are not in the same folder
 */
function gautoupgrade_init_container($callerFilePath)
{
    // defines.inc.php can not exists (1.3.0.1 for example)
    // but we need _PS_ROOT_DIR_
    if (!defined('_PS_ROOT_DIR_')) {
        define('_PS_ROOT_DIR_', realpath($callerFilePath . '/../../'));
    }

    if (!defined('_PS_MODULE_DIR_')) {
        define('_PS_MODULE_DIR_', _PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR);
    }

    define('GAUTOUPGRADE_MODULE_DIR', _PS_MODULE_DIR_ . 'gautoupgrade' . DIRECTORY_SEPARATOR);
    require_once GAUTOUPGRADE_MODULE_DIR . 'functions.php';
    require_once GAUTOUPGRADE_MODULE_DIR . 'vendor/autoload.php';

    $_dir = Tools14::getValue('dir');
    if (PHP_SAPI === 'cli') {
        $options = getopt('', array('dir:'));
        if (isset($options['dir'])) {
            //$_POST['dir'] = $options['dir'];
            $_dir = $options['dir'];
        }
    }
    // the following test confirm the directory exists
    //if (empty($_POST['dir'])) {
    if ($_dir == '') {
        echo 'No admin directory provided (dir). module cannot proceed.';
        exit(1);
    }

    //$dir = Tools14::safeOutput(Tools14::getValue('dir'));
    $dir = Tools14::safeOutput($_dir);
    define('_PS_ADMIN_DIR_', _PS_ROOT_DIR_ . DIRECTORY_SEPARATOR . $dir);

    if (_PS_ADMIN_DIR_ !== realpath(_PS_ADMIN_DIR_)) {
        echo 'wrong directory: ' . $dir;
        exit(1);
    }

    $container = new \PrestaShop\Module\GautoUpgrade\UpgradeContainer(_PS_ROOT_DIR_, _PS_ADMIN_DIR_);
    $container->getState()->importFromArray(empty($_REQUEST['params']) ? array() : $_REQUEST['params']);

    return $container;
}
